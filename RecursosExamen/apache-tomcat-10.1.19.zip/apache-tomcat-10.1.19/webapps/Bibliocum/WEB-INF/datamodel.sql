-- Database creation
CREATE DATABASE bibliocum;

-- Datebase
USE bibliocum

CREATE TABLE Book (
    ID_book INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    theme VARCHAR(100),
    rating DECIMAL(3,2),
    image VARCHAR(255), -- Image Path
    date_added DATE NOT NULL DEFAULT CURRENT_DATE
);


-- User table
CREATE TABLE User (
    ID_user INT PRIMARY KEY AUTO_INCREMENT, -- primary key
    name VARCHAR(100) NOT NULL, -- Nombre del usuario
    lastname VARCHAR(100) NOT NULL, -- Apellido del usuario
    email VARCHAR(255) NOT NULL, -- Correo electrónico del usuario
    pass VARCHAR(100) NOT NULL, -- Contraseña del usuario
    image VARCHAR(255), -- Image Path
    priv ENUM('normal', 'admin', 'secretary') DEFAULT 'normal' -- user privilege (default privilege - normal)
);

-- Booking table
CREATE TABLE Booking (
    ID_user INT, -- user reference
    ID_book INT, -- book reference
    reser_date DATE, -- booking date
    return_date DATE, -- return date
    PRIMARY KEY (ID_book, reser_date), -- composite primary key
    FOREIGN KEY (ID_user) REFERENCES User(ID_user), -- foreign key (user reference)
    FOREIGN KEY (ID_book) REFERENCES Book(ID_book) -- foreign key (book reference)
);

-- Rating table
CREATE TABLE Rating (
    ID_rating INT PRIMARY KEY AUTO_INCREMENT, -- primary key
    ID_book INT, -- book reference
    ID_user INT, -- user reference
    rating DECIMAL(3,2), -- book rating
    comment VARCHAR(250) NOT NULL, -- book review
    review_date DATE, -- review date
    image VARCHAR(255), -- Image Path
    FOREIGN KEY (ID_user) REFERENCES User(ID_user), -- foreign key (user reference)
    FOREIGN KEY (ID_book) REFERENCES Book(ID_book) -- foreign ley (book reference)
);

