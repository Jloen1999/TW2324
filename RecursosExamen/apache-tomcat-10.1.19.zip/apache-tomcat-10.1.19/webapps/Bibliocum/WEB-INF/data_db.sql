-- Insert book data
INSERT INTO Book (title, author, theme, rating, image, date_added) VALUES
('Control Your Mind and Master Your Feelings', 'Eric Robertson', 'Health', 4.5, '../Bibliocum/img/book_01.jpg', '2024-04-15'),
('Atomic Habits', 'James Clear', 'Health', 4.5, '../Bibliocum/img/book_02.jpg', '2024-04-15'),
('Power. Die 48 Gesetze der Macht. Ein Joost- Elffers- Buch.', 'Robert Greene and Joost Elffers', 'Health', 3.4, '../Bibliocum/img/book_03.jpg', '2024-04-15'),
('Twisted Love', 'Ana Huang', 'Fiction', 4, '../Bibliocum/img/book_04.jpg', '2024-04-15'),
('Twisted Games', 'Ana Huang', 'Romance', 5, '../Bibliocum/img/book_05.jpg', '2024-04-15'),
('A Sutil Arte de Ligar o F*da-se', 'Mark Manson', 'Self-realization', 3.5, '../Bibliocum/img/book_06.jpg', '2024-04-15');


-- Insert user data
INSERT INTO User (name, lastname, email, pass, priv) VALUES
('admin', 'admin123', 'admin@example.com', 'adminpass', 'admin'),
('secretary', 'secretary456', 'secretary@example.com', 'secretpass', 'secretary'),
('normal', 'user789', 'user@example.com', 'userpass', 'normal');

-- Insert Bookings
INSERT INTO Booking (ID_user, ID_book, reser_date, return_date) VALUES
(3, 1, '2024-04-12', '2024-04-19'); 

-- Insert Rating
INSERT INTO Rating (ID_book, ID_user, rating, comment, review_date) VALUES
(1, 3, 4.2, 'Excelente libro, muy recomendado', '2024-04-15'),
(2, 3, 4.6, 'Una obra maestra de la literatura', '2024-04-16');
